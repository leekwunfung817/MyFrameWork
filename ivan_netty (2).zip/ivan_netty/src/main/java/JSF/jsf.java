/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JSF;
import javax.faces.bean.ManagedBean;
import javax.faces.webapp.FacesServlet;
/**
 *
 * @author Reinfo
 */
@ManagedBean
public class jsf {
    
    final String world = "Hello World!";

    public String getworld() {
        return world;
    }
}
