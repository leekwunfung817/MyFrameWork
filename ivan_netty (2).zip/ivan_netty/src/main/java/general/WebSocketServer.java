package general;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import net.mengkangs.Response;
import net.mengkangs.Client;
import net.mengkangs.WebSocketServerInitializer;

public final class WebSocketServer {

    private static final int PORT = 8083;

    public static void main(String[] args) throws Exception {
        EventLoopGroup bossGroup = new NioEventLoopGroup(1);
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .handler(new LoggingHandler(LogLevel.INFO))
                    .childHandler(new WebSocketServerInitializer());

            Channel ch = b.bind(PORT).sync().channel();
            ch.closeFuture().sync();
        } finally {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }

    public static Response replyMessage(Client client, String message) {
        Response res = new Response();
        
//        res.getData().put("id", client.getId());
        res.getData().put("message", "I received");
//        res.getData().put("ts", System.currentTimeMillis());// 返回毫秒数
        return res;
    }

    public static Response broadcastMessage(Client client, String message) {
        return null;
//        Response res = new Response();
//        res.getData().put("id", client.getId());
//        res.getData().put("message", message);
//        res.getData().put("ts", System.currentTimeMillis());// 返回毫秒数
//        return res;
    }
}
